<?php

/**
 * default.php
 *
 * default application controller
 *
 * @package		TinyMVC
 * @author		Monte Ohrt
 */

class Default_Controller extends TinyMVC_Controller
{
  function index()
  {
    $this->view->display('index_view');
  }
  
  	function test()
	{
		$this->load->library('mojagclass','mojagclass');
		echo $this->mojagclass->getVersion();
	}
  
	function tdbase()
	{
	    // load the model
    $this->load->model('Page_Model','page');
    // alternately, specify the connection pool (default is "default")
    // $this->load->model('Page_Model','page',null,'mypool');
 
    // use the model to gather data
    $title = $this->page->get_title();
    $body_text = $this->page->get_body_text();
	$sites = $this->page->getsites();
	//print_r($sites);
	exit;

   }
}

?>
